"""Application-specific context extractors."""
